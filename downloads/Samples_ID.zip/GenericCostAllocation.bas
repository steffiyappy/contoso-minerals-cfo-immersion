Attribute VB_Name = "GenericCostAllocation"
Option Explicit

' Original synthetic training example. RunAllocation is the only entry point.
' Allocation!A:L is exclusively generated output; source worksheets are read-only.
Public Sub RunAllocation()
    Dim wb As Workbook, pools As Worksheet, drivers As Worksheet
    Dim output As Worksheet, audit As Worksheet, guide As Worksheet
    Dim p As Variant, d As Variant, result() As Variant
    Dim groups As Object, weights As Object
    Dim keys As Variant, poolKey As String, driverKey As String
    Dim nPools As Long, nDrivers As Long, i As Long, j As Long, k As Long
    Dim r As Long, sourceRow As Long, lastRow As Long, outRow As Long
    Dim cents As Currency, totalInput As Currency, totalOutput As Currency
    Dim totalWeight As Variant, numerator As Variant
    Dim base(0 To 2) As Currency, remainder(0 To 2) As Variant
    Dim values(0 To 2) As Currency, extra(0 To 2) As Long
    Dim leftOver As Long, best As Long, pass As Long
    Dim siteIDs As Variant, siteNames As Variant, basis As String
    Dim failure As String, oldScreenUpdating As Boolean

    oldScreenUpdating = Application.ScreenUpdating
    On Error GoTo Failed
    Set wb = ThisWorkbook
    Set pools = wb.Worksheets("Cost_Pools")
    Set drivers = wb.Worksheets("Drivers")
    Set output = wb.Worksheets("Allocation")
    Set audit = wb.Worksheets("Audit_Run")
    Set guide = wb.Worksheets("Guide")
    CheckHeaders pools, Array("Period", "Pool_ID", "Pool_Name", "Driver_Basis", "Amount_USD")
    CheckHeaders drivers, Array("Period", "Pool_ID", "Site_ID", "Site_Name", "Driver_Basis", "Driver_Value")
    CheckHeaders output, Array("Period", "Pool_ID", "Pool_Name", "Site_ID", "Site_Name", "Driver_Basis", "Driver_Value", "Driver_Total", "Share", "Pool_Amount_USD", "Allocated_USD", "Rounding_Adjustment_Cents")
    CheckHeaders audit, Array("Run_ID", "Run_Timestamp_Local", "Status", "Pool_Count", "Driver_Row_Count", "Allocation_Row_Count", "Input_Total_USD", "Allocated_Total_USD", "Message")
    nPools = LastDataRow(pools, 5) - 1
    nDrivers = LastDataRow(drivers, 6) - 1
    Require nPools > 0, "Cost_Pools has no input rows."
    Require nDrivers > 0, "Drivers has no input rows."
    p = pools.Range("A2:E" & nPools + 1).Value2
    d = drivers.Range("A2:F" & nDrivers + 1).Value2
    Set groups = CreateObject("Scripting.Dictionary")
    Set weights = CreateObject("Scripting.Dictionary")
    groups.CompareMode = vbBinaryCompare
    weights.CompareMode = vbBinaryCompare
    siteIDs = Array("S01", "S02", "S03")
    siteNames = Array("North Valley / Lembah Utara", "East Ridge / Bukit Timur", "Central Project / Proyek Sentral")

    For i = 1 To nPools
        poolKey = PeriodKey(p(i, 1), "Cost_Pools row " & i + 1) & "|" & CleanID(p(i, 2))
        Require Not groups.Exists(poolKey), "Duplicate period/pool: " & poolKey
        Require Len(Trim$(CStr(p(i, 3)))) > 0, "Missing pool name: " & poolKey
        Require ValidBasis(p(i, 4)), "Unknown driver basis: " & poolKey
        Require IsNumberValue(p(i, 5)), "Missing/non-numeric amount: " & poolKey
        Require p(i, 5) >= 0 And p(i, 5) <= 10000000, "Amount must be USD 0 to 10,000,000: " & poolKey
        Require CDec(p(i, 5)) * 100 = Fix(CDec(p(i, 5)) * 100), "Amount must have at most two decimals: " & poolKey
        groups.Add poolKey, i
        totalInput = totalInput + CCur(p(i, 5))
    Next i

    For i = 1 To nDrivers
        poolKey = PeriodKey(d(i, 1), "Drivers row " & i + 1) & "|" & CleanID(d(i, 2))
        Require groups.Exists(poolKey), "Unmatched driver period/pool: " & poolKey
        sourceRow = groups(poolKey)
        Require CStr(d(i, 5)) = CStr(p(sourceRow, 4)), "Driver basis mismatch: " & poolKey
        j = SiteIndex(d(i, 3))
        Require j >= 0, "Unknown site at Drivers row " & i + 1
        Require CStr(d(i, 4)) = CStr(siteNames(j)), "Site name does not match its ID at Drivers row " & i + 1
        driverKey = poolKey & "|" & siteIDs(j)
        Require Not weights.Exists(driverKey), "Duplicate site driver: " & driverKey
        Require IsNumberValue(d(i, 6)), "Missing/non-numeric driver: " & driverKey
        Require d(i, 6) >= 0 And d(i, 6) <= 1000000, "Driver must be 0 to 1,000,000: " & driverKey
        Require CDec(d(i, 6)) = Fix(CDec(d(i, 6))), "Drivers use whole units only: " & driverKey
        weights.Add driverKey, CCur(d(i, 6))
    Next i

    keys = groups.Keys
    SortKeys keys
    ReDim result(1 To nPools * 3, 1 To 12)
    For k = LBound(keys) To UBound(keys)
        poolKey = CStr(keys(k))
        sourceRow = groups(poolKey)
        cents = CCur(CDec(p(sourceRow, 5)) * 100)
        totalWeight = CDec(0)
        For j = 0 To 2
            driverKey = poolKey & "|" & siteIDs(j)
            Require weights.Exists(driverKey), "Missing site driver: " & driverKey
            values(j) = weights(driverKey)
            totalWeight = totalWeight + CDec(values(j))
            extra(j) = 0
        Next j
        Require totalWeight > 0, "Zero-total drivers: " & poolKey
        leftOver = 0
        For j = 0 To 2
            numerator = CDec(cents) * CDec(values(j))
            base(j) = CCur(Fix(numerator / totalWeight))
            remainder(j) = numerator - CDec(base(j)) * totalWeight
        Next j
        leftOver = CLng(cents - base(0) - base(1) - base(2))
        Require leftOver >= 0 And leftOver <= 2, "Internal remainder check failed: " & poolKey
        ' Exact Decimal remainders; stable S01, S02, S03 order breaks ties.
        For pass = 1 To leftOver
            best = -1
            For j = 0 To 2
                If extra(j) = 0 Then
                    If best = -1 Then
                        best = j
                    ElseIf remainder(j) > remainder(best) Then
                        best = j
                    End If
                End If
            Next j
            extra(best) = 1
        Next pass
        For j = 0 To 2
            outRow = outRow + 1
            result(outRow, 1) = p(sourceRow, 1)
            result(outRow, 2) = p(sourceRow, 2)
            result(outRow, 3) = p(sourceRow, 3)
            result(outRow, 4) = siteIDs(j)
            result(outRow, 5) = siteNames(j)
            result(outRow, 6) = p(sourceRow, 4)
            result(outRow, 7) = values(j)
            result(outRow, 8) = CCur(totalWeight)
            result(outRow, 9) = CDbl(values(j)) / CDbl(totalWeight)
            result(outRow, 10) = p(sourceRow, 5)
            result(outRow, 11) = (base(j) + extra(j)) / 100
            result(outRow, 12) = extra(j)
            totalOutput = totalOutput + CCur(result(outRow, 11))
        Next j
    Next k
    Require totalInput = totalOutput, "Internal total reconciliation failed."

    ' All validation and calculation finish before replacing owned output.
    oldScreenUpdating = Application.ScreenUpdating
    Application.ScreenUpdating = False
    lastRow = LastDataRow(output, 12)
    If lastRow >= 2 Then output.Range("A2:L" & lastRow).ClearContents
    output.Range("A2").Resize(outRow, 12).Value2 = result
    output.Range("A2:A" & outRow + 1).NumberFormat = "mmm yyyy"
    output.Range("G2:H" & outRow + 1).NumberFormat = "#,##0"
    output.Range("I2:I" & outRow + 1).NumberFormat = "0.00%"
    output.Range("J2:K" & outRow + 1).NumberFormat = """USD ""#,##0.00"
    Application.ScreenUpdating = oldScreenUpdating
    AppendAudit audit, "SUCCESS", nPools, nDrivers, outRow, totalInput, totalOutput, "Reconciled exactly; deterministic largest remainder; sources unchanged."
    guide.Range("C16").Value2 = "SUCCESS / BERHASIL | " & outRow & " rows / baris | " & Format$(Now, "yyyy-mm-dd hh:nn:ss")
    Exit Sub

Failed:
    failure = Err.Description
    On Error Resume Next
    ' No dialogs, automatic runs, file writes, or security-setting changes.
    If Not audit Is Nothing Then AppendAudit audit, "FAILED", nPools, nDrivers, 0, 0, 0, failure
    If Not guide Is Nothing Then guide.Range("C16").Value2 = "FAILED / GAGAL | " & failure
    Application.ScreenUpdating = oldScreenUpdating
End Sub

Private Sub Require(ByVal condition As Boolean, ByVal message As String)
    If Not condition Then Err.Raise vbObjectError + 2601, "RunAllocation", message
End Sub

Private Function IsNumberValue(ByVal value As Variant) As Boolean
    If IsError(value) Or IsEmpty(value) Then Exit Function
    If VarType(value) = vbString Or VarType(value) = vbBoolean Then Exit Function
    IsNumberValue = IsNumeric(value)
End Function

Private Function PeriodKey(ByVal value As Variant, ByVal location As String) As String
    Dim dt As Date
    Require IsNumberValue(value), "Period must be a real Excel month-start date: " & location
    Require value = Fix(value), "Period contains a time component: " & location
    Require value >= CDbl(DateSerial(2026, 6, 1)) And value <= CDbl(DateSerial(2026, 8, 1)), "Period outside Jun-Aug 2026: " & location
    dt = CDate(value)
    Require Day(dt) = 1, "Period must be first day of month: " & location
    PeriodKey = Format$(dt, "yyyy-mm")
End Function

Private Function CleanID(ByVal value As Variant) As String
    Dim text As String
    text = CStr(value)
    Require Len(text) > 0 And text = Trim$(text) And InStr(text, "|") = 0, "Pool_ID is missing or malformed."
    Require text = UCase$(text), "Pool_ID must use uppercase letters."
    CleanID = text
End Function

Private Function ValidBasis(ByVal value As Variant) As Boolean
    ValidBasis = CStr(value) = "headcount" Or CStr(value) = "tonnes" Or CStr(value) = "tickets"
End Function

Private Function SiteIndex(ByVal value As Variant) As Long
    SiteIndex = -1
    Select Case CStr(value)
        Case "S01": SiteIndex = 0
        Case "S02": SiteIndex = 1
        Case "S03": SiteIndex = 2
    End Select
End Function

Private Sub CheckHeaders(ByVal ws As Worksheet, ByVal expected As Variant)
    Dim i As Long
    For i = LBound(expected) To UBound(expected)
        Require CStr(ws.Cells(1, i + 1).Value2) = CStr(expected(i)), "Header mismatch: " & ws.Name & " column " & i + 1
    Next i
End Sub

Private Function LastDataRow(ByVal ws As Worksheet, ByVal width As Long) As Long
    Dim j As Long, row As Long
    LastDataRow = 1
    For j = 1 To width
        row = ws.Cells(ws.Rows.Count, j).End(xlUp).row
        If row > LastDataRow Then LastDataRow = row
    Next j
End Function

Private Sub SortKeys(ByRef keys As Variant)
    Dim i As Long, j As Long, current As Variant
    For i = LBound(keys) + 1 To UBound(keys)
        current = keys(i)
        j = i - 1
        Do While j >= LBound(keys)
            If StrComp(CStr(keys(j)), CStr(current), vbBinaryCompare) <= 0 Then Exit Do
            keys(j + 1) = keys(j)
            j = j - 1
        Loop
        keys(j + 1) = current
    Next i
End Sub

Private Sub AppendAudit(ByVal ws As Worksheet, ByVal status As String, ByVal pools As Long, ByVal drivers As Long, ByVal allocations As Long, ByVal inputUSD As Currency, ByVal outputUSD As Currency, ByVal message As String)
    Dim row As Long, record(1 To 1, 1 To 9) As Variant
    row = LastDataRow(ws, 9) + 1
    record(1, 1) = row - 1
    record(1, 2) = Now
    record(1, 3) = status
    record(1, 4) = pools
    record(1, 5) = drivers
    record(1, 6) = allocations
    record(1, 7) = inputUSD
    record(1, 8) = outputUSD
    record(1, 9) = message
    ws.Cells(row, 1).Resize(1, 9).Value2 = record
    ws.Cells(row, 2).NumberFormat = "yyyy-mm-dd hh:mm:ss"
    ws.Cells(row, 7).Resize(1, 2).NumberFormat = """USD ""#,##0.00"
End Sub
